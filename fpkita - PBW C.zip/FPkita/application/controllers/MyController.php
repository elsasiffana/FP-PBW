<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MyController extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('model');
	}
	public function index()
	{
		$data['err_message'] = ""; //untuk load controllet ke view biasanya data butuh dibuat array, didfunction loginalam array data tersembut ada error message.
		$this->load->view('sebelum/index');
	}
	function home(){
		$this->load->view('sebelum/index');
	}
	function homee(){
		$this->load->view('sesudah/index');
	}
	function login(){
		$username = $this->input->post('username');
		$enpass = $this->input->post('pass');
		$password = md5($enpass);
		//get data
		$isLogin = $this->model->login_authen($username,$password);
		$i=$this->model->authen_user($username);

		if($isLogin->num_rows()==1 && $i[0]['authentication']< 3 ){
			foreach ($isLogin->result()as $user) {
			$user_sess['username'] = $user->username;
			$this->session->set_userdata($user_sess);
			}
			//$this->load->view('sesudah/index');
			$this->homee($username);
		}
		else{
			if($i[0]['authentication']< 3){
				//i di return dalam array 2 dimensi
				$this->model->wrong_password($username, $i[0]['authentication']+1);
				$data['err_message'] = "GAGAL LOGIN!".($i[0]['authentication']+1); //untuk load controllet ke view biasanya data butuh dibuat array, didalam array data tersembut ada error message.
				$this->load->view('sebelum/index');
			}
			else{
				$data['err_message'] = "AKUN TERBLOCKIR"; //untuk load controllet ke view biasanya data butuh dibuat array, didalam array data tersembut ada error message.
				$this->load->view('sebelum/index');
			}
		
		}


	}
	function createakun(){
		$passen = $this->input->post('password');
		$newpass = md5($passen);
		$data = array(
				'username' => $this->input->post('username'),
				'name' => $this->input->post('name'),
				'email' => $this->input->post('email'),
				'phone' => $this->input->post('phone'),
				//'password' => $this->input->post('password')
				'password'=> $newpass,
				'address' => $this->input->post('address')
			);
		$this->model->addAkun($data);
		$this->index();
	}

	function signup(){
		$this->load->view('formsignup');
	}

	function logout(){
		$this->session>session_destroy();
		$this->homee();
	}
}
