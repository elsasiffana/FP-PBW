-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2017 at 05:01 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fpkita`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(200) NOT NULL,
  `authentication` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`, `authentication`) VALUES
('pbw', '01bfaf73d6e354408d7417ac7800f11bd38b9865', 0);

-- --------------------------------------------------------

--
-- Table structure for table `categori`
--

CREATE TABLE `categori` (
  `id_cat` int(10) NOT NULL,
  `nama_cat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categori`
--

INSERT INTO `categori` (`id_cat`, `nama_cat`) VALUES
(1, 'Traditional Cake'),
(2, 'Birthday Cake'),
(3, 'Nasi Kotak');

-- --------------------------------------------------------

--
-- Table structure for table `detailorder`
--

CREATE TABLE `detailorder` (
  `id` int(11) NOT NULL,
  `orderid` int(11) NOT NULL,
  `kodeproduct` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detailorder`
--

INSERT INTO `detailorder` (`id`, `orderid`, `kodeproduct`, `harga`, `jumlah`) VALUES
(17, 15244, 3, 2000, 2),
(18, 15244, 5, 2000, 1),
(19, 15244, 9, 2000, 1),
(20, 15244, 13, 15000, 1),
(21, 77514, 2, 2000, 1),
(22, 77514, 3, 2000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `ID` int(11) NOT NULL,
  `user` varchar(200) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `date` varchar(40) NOT NULL,
  `tanggalambil` varchar(200) NOT NULL,
  `total` int(11) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`ID`, `user`, `phone`, `date`, `tanggalambil`, `total`, `status`) VALUES
(15244, 'elsash', '08123', '2017-05-30 07:28:44', '1 Mei 2017', 23000, 'Done'),
(77514, 'elsash', '098764', '2017-05-30 12:27:38', '2017-09-08', 4000, 'On Progress');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(10) NOT NULL,
  `nama_product` varchar(100) NOT NULL,
  `deskripsi` varchar(100) NOT NULL,
  `harga` varchar(20) NOT NULL,
  `kategori` int(10) NOT NULL,
  `gambar` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `nama_product`, `deskripsi`, `harga`, `kategori`, `gambar`) VALUES
(1, 'Kue Sus', 'kue dengan berbentuk bundar dengan rongga berisi fla yang manis', '2000', 1, '01.jpg'),
(2, 'Onde - Onde', 'Kue tradisional dengan taburan wijennya dan isi kacang hijau manisnya.', '2000', 1, '02.jpg'),
(3, 'Kue Lapis', 'Kue kukus yang rasanya manis gurih dengan lapisan warna - warni.', '2000', 1, '03.jpg'),
(4, 'Kue Risoles', 'Risoles merupakan pastri dengan isi  sayuran atau daging ayam cincang yang digoreng', '2000', 1, '04.jpg'),
(5, 'Kue Pastel Basah', 'Pastel ini berisikan sayuran dan telor yang baik untuk kesehatan. ', '2000', 1, '05.jpg'),
(6, 'Kue Dadar Gulung', 'Kue gurih dengan isi kelapa yang manis dan nikmat.', '2000', 1, '06.jpg'),
(7, 'Kue Ku', 'Kue basah yang kenyal dan berisikan kacang hijau yang manis.', '2000', 1, '07.jpg'),
(8, 'Kue Cumcum', 'Kue tanduk yang berlapis-lapis dengan rasa gurih manis berisikan fla', '2000', 1, '08.jpg'),
(9, 'Kue Bikang', 'Kue warna - warni yang dicetak mekar dengan rasa manis dan gurih. Sangat cocok disantap saat santai', '2000', 1, '09.jpg'),
(10, 'Kue Kukus', 'Kue dengan bentuk bunga yang memiliki tekstur lembut dan manis', '2000', 1, '10.jpg'),
(11, 'Paket Nasi 1', 'Nasi dengan pecel lele. Isi dari paket ini adalah Nasi Putih + Lele Goreng + Lalapan + Sambal.', '10000', 3, '011.jpg'),
(12, 'Paket Nasi 2', 'Isi Paket ini adalah Nasi Putih + Ayam Panggang Besar + Lalapan + Sambal.', '15000', 3, '012.jpg'),
(13, 'Paket Nasi 3', 'Nasi dengan ayam bakar. Isi dari paket ini adalah Nasi Putih + Ayam Bakar Besar + Lalapan + Sambal.', '15000', 3, '013.jpg'),
(14, 'Paket Nasi 4', 'Nasi Rames. Isi dari paket 4 ini adalah Nasi Putih + Sambal Goreng Kentang + Mie + Acar + Ayam.', '15000', 3, '014.jpg'),
(15, 'Paket Nasi 5', 'Paket nasi kuning. Isinya adalah Nasi Kuning + Mie + Sambal Goreng Tempe Kering + Telur + Ayam ', '10000', 3, '015.jpg'),
(21, 'Paket Ultah 1', 'Kue ulang tahun dengan diamer 30 cm.', '50000', 2, '021.jpg'),
(22, 'Paket Ultah 2', 'Kue ulang tahun dengan diameter 30 cm yang terdiri dari 2 sub kue.', '130000', 2, '022.jpg'),
(23, 'PaketUltah 3', 'Kue ulang tahun dengan diamter 30 cm yang terdiri dari 3 sub kue.', '175000', 2, '023.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(200) NOT NULL,
  `authentication` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `name`, `email`, `phone`, `address`, `authentication`) VALUES
('elsaaja', '86ef04684938e6bf4252a4fde4de80aa', 'elsa', 'elsa@gmail.com', '189292010', 'nganjuk', 0),
('elsash', '68faffc68e1c53942d47ada2627cca0f', 'elsa', 'elsa@gmail.com', '0987', 'Nganjuk', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `categori`
--
ALTER TABLE `categori`
  ADD PRIMARY KEY (`id_cat`);

--
-- Indexes for table `detailorder`
--
ALTER TABLE `detailorder`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orderid` (`orderid`),
  ADD KEY `kodeproduct` (`kodeproduct`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kategori` (`kategori`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `detailorder`
--
ALTER TABLE `detailorder`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`kategori`) REFERENCES `categori` (`id_cat`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
